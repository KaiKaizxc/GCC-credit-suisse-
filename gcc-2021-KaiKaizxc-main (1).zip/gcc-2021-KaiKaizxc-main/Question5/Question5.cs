using System;

public class Solution
{
     public static string sol(string n)
    {
       

    }
	public static void Main()
	{
        string n= Console.ReadLine();                 
        string answer=sol(n);
        Console.WriteLine(answer);
	}
}
