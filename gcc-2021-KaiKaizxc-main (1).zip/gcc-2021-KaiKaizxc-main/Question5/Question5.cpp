using namespace std;
#include <string>
#include <iostream>

string solution(string n){
    // code here
    //return "A";
    //return "B"
}

/*  Do not edit below code */
int main() {
	string  n;
	cin >> n;	
    string answer=solution(n);
	cout << answer << endl;	
}
