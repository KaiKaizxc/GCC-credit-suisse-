import java.io.*;
import java.math.*;
import java.text.*;
import java.util.*;
import java.util.regex.*;

class GroupFormation {

    static void theHackathon(int n, int m, int a, int b, int f, int s, int t) {
        // Participant code here
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String[] inputdata = scanner.nextLine().split(" ");

        int n = Integer.parseInt(inputdata[0]);

        int m = Integer.parseInt(inputdata[1]);

        int a = Integer.parseInt(inputdata[2]);

        int b = Integer.parseInt(inputdata[3]);

        int f = Integer.parseInt(inputdata[4]);

        int s = Integer.parseInt(inputdata[5]);

        int t = Integer.parseInt(inputdata[6]);

        theHackathon(n, m, a, b, f, s, t);

        scanner.close();
    }
}
