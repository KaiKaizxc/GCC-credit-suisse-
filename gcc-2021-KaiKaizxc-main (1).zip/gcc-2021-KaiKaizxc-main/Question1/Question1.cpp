
using namespace std;
#include <string>
#include <iostream>

int solution(int n){
    // code here
}

/*  Do not edit below code */
int main() {
	int n;
	cin >> n;	
    int answer=solution(n);
	cout << answer << endl;	
}
